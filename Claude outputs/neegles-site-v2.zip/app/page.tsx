import InkHero from "@/components/home/InkHero";
import Studio from "@/components/home/Studio";
import WorkDeck from "@/components/home/WorkDeck";
import ServiceRows from "@/components/home/ServiceRows";
import Tickets from "@/components/home/Tickets";
import ProcessRail from "@/components/home/ProcessRail";
import VoicesType from "@/components/home/VoicesType";
import Dive from "@/components/Dive";

export default function Home() {
  return (
    <>
      <InkHero />
      <Studio />
      <WorkDeck />
      <ServiceRows />
      <Tickets />
      <ProcessRail />
      <VoicesType />
      <Dive />
    </>
  );
}
