import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import TLink from "@/components/site/TLink";
import { industries, capabilities } from "@/lib/content";

export function generateStaticParams() {
  return industries.map((i) => ({ slug: i.id }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const ind = industries.find((x) => x.id === slug);
  return ind ? { title: ind.name, description: ind.headline } : {};
}

export default async function IndustryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const i = industries.findIndex((x) => x.id === slug);
  if (i < 0) notFound();
  const ind = industries[i];
  const next = industries[(i + 1) % industries.length];
  return (
    <>
      <section className="indh" data-thread="0.85">
        <figure className="indh-img" aria-hidden="true">
          <Image src={ind.image} alt="" fill priority sizes="100vw" style={{ objectFit: "cover" }} data-parallax="14" />
        </figure>
        <div className="indh-in">
          <p className="kicker">Industries · 0{i + 1}</p>
          <h1 className="indh-title" data-type data-type-now data-type-delay="0.25" data-type-keep>
            {ind.name}
          </h1>
          <p className="indh-line" data-fade="0.5">
            {ind.headline}
          </p>
        </div>
      </section>
      <section className="mods" data-thread="0.1">
        <div className="sec-head">
          <p className="kicker">What we build for {ind.name.toLowerCase()}</p>
          <h2 className="t-xl" data-type>
            The <span className="dim">modules.</span>
          </h2>
        </div>
        <ol className="mods-grid" data-stagger>
          {ind.modules.map((m, k) => (
            <li key={m} className="mod">
              <span className="mod-n">0{k + 1}</span>
              <span className="mod-name">{m}</span>
              <span className="mod-arrow" aria-hidden="true">
                ↘
              </span>
            </li>
          ))}
        </ol>
      </section>
      <section className="ind-how" data-thread="0.9">
        <p className="kicker">How it comes together</p>
        <p className="ind-how-big" data-type data-type-max="3">
          Each module is built with the same five practices: {capabilities.map((c) => c.title.toLowerCase()).join(", ")}. You get one
          system, not five vendors.
        </p>
      </section>
      <section className="case-next" data-thread="0.5">
        <p className="kicker">Next industry</p>
        <TLink href={`/industries/${next.id}`} className="case-next-link" data-cursor="Next" data-lean>
          {next.name} <span aria-hidden="true">→</span>
        </TLink>
      </section>
    </>
  );
}
