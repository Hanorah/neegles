import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/pages/PageHero";
import { labs } from "@/lib/content";

export const metadata: Metadata = { title: "Labs", description: labs.sub };

export default function LabsPage() {
  return (
    <>
      <PageHero kicker="Neegles Labs" title="Experiments" dim="that ship." intro={labs.sub} meta={labs.practices.map((p) => p.name)} />
      <section className="labs" data-thread="0.92">
        {labs.items.map((l, i) => (
          <article key={l.id} id={l.id} className={`lab ${i % 2 ? "lab-r" : ""}`}>
            <figure className="lab-img" data-reveal data-cursor={l.name}>
              <Image src={l.image} alt={`${l.name}: ${l.body}`} fill sizes="(max-width: 760px) 100vw, 62vw" style={{ objectFit: "cover", objectPosition: "50% 0%" }} />
            </figure>
            <div className="lab-copy">
              <span className="lab-n">L/0{i + 1}</span>
              <h2 className="lab-name" data-type>
                {l.name}
              </h2>
              <p className="lab-tag">{l.tag}</p>
              <p className="lab-body" data-fade>
                {l.body}
              </p>
            </div>
          </article>
        ))}
      </section>
      <section className="practices" data-thread="0.1">
        <div className="sec-head sec-head-dark">
          <p className="kicker">Practices</p>
          <h2 className="t-xl" data-type>
            How Labs <span className="dim">thinks.</span>
          </h2>
        </div>
        <ul className="prac" data-stagger>
          {labs.practices.map((p, i) => (
            <li key={p.name}>
              <span>0{i + 1}</span>
              <strong>{p.name}</strong>
              <em>{p.line}</em>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
