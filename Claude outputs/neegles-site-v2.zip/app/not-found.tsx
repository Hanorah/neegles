import TLink from "@/components/site/TLink";

export default function NotFound() {
  return (
    <section className="nf" data-thread="0.5">
      <p className="kicker">404</p>
      <h1 className="phero-title" data-type data-type-now data-type-keep>
        This page didn&apos;t <span className="dim">ship.</span>
      </h1>
      <TLink href="/" className="pill pill-paper" data-magnetic>
        Back home <span aria-hidden="true">→</span>
      </TLink>
    </section>
  );
}
