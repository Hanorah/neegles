import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/pages/PageHero";
import ProcessRail from "@/components/home/ProcessRail";
import { company, approach } from "@/lib/content";

export const metadata: Metadata = { title: "About", description: company.description };

const reasons = [
  { n: "01", title: "Problem-first thinking", body: company.mission },
  { n: "02", title: "Built for Africa, made for anywhere", body: company.vision },
  { n: "03", title: "Support that stays", body: "Technical support and continuous improvement to keep your product running at its best." },
];

export default function AboutPage() {
  return (
    <>
      <PageHero kicker="About Neegles" title="We build" dim="with intent." intro={company.description} meta={["Web", "Mobile", "Enterprise", "Cloud", "AI", "Automation"]} />
      <section className="manifest" data-thread="0.9">
        <div className="mf-row">
          <p className="kicker">Mission</p>
          <p className="mf-big" data-type data-type-max="2.6">
            {company.mission}
          </p>
        </div>
        <div className="mf-row">
          <p className="kicker">Vision</p>
          <p className="mf-big" data-type data-type-max="2.6">
            {company.vision}
          </p>
        </div>
      </section>
      <section className="about-img" data-thread="0.12">
        <figure data-reveal>
          <Image src="/industries/professional-services.webp" alt="A team reviewing dashboards together" fill sizes="100vw" style={{ objectFit: "cover" }} data-parallax="16" />
        </figure>
        <p className="about-cap" data-fade>
          Ideas without engineering are just slides.
        </p>
      </section>
      <section className="reasons" data-thread="0.88">
        <div className="sec-head">
          <p className="kicker">Why Neegles</p>
          <h2 className="t-xl" data-type>
            Why teams <span className="dim">choose us.</span>
          </h2>
          <p className="sec-side" data-fade>
            {approach.statement}
          </p>
        </div>
        <ol className="rs" data-stagger>
          {reasons.map((r) => (
            <li key={r.n} className="rs-card">
              <span className="rs-n">{r.n}</span>
              <h3>{r.title}</h3>
              <p>{r.body}</p>
            </li>
          ))}
        </ol>
      </section>
      <ProcessRail />
    </>
  );
}
