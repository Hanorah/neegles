"use client";

import { useEffect, useRef, useState } from "react";
import { voices } from "@/lib/content";

/** Client voices, typed out, held, and erased — one after another. */
export default function VoicesType() {
  const [i, setI] = useState(0);
  const [txt, setTxt] = useState("");
  const [live, setLive] = useState(false);
  const root = useRef<HTMLElement>(null);
  const v = voices[i];

  useEffect(() => {
    const io = new IntersectionObserver(([e]) => setLive(e.isIntersecting), { threshold: 0.3 });
    if (root.current) io.observe(root.current);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!live) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setTxt(v.quote);
      return;
    }
    let k = 0;
    let dir = 1;
    let hold = 0;
    const full = v.quote;
    const id = setInterval(() => {
      if (dir === 1) {
        k++;
        setTxt(full.slice(0, k));
        if (k >= full.length) {
          dir = 0;
          hold = 0;
        }
      } else if (dir === 0) {
        hold++;
        if (hold > 70) dir = -1;
      } else {
        k = Math.max(0, k - 3);
        setTxt(full.slice(0, k));
        if (k === 0) {
          clearInterval(id);
          setI((n) => (n + 1) % voices.length);
        }
      }
    }, 38);
    return () => clearInterval(id);
  }, [i, live, v.quote]);

  return (
    <section ref={root} className="voices" aria-labelledby="vo-title" data-thread="0.88" data-thread-loop>
      <div className="sec-head sec-head-dark">
        <p className="kicker">Client voices</p>
        <h2 id="vo-title" className="t-xl" data-type>
          In their <span className="dim">words.</span>
        </h2>
      </div>
      <figure className="vo">
        <blockquote className="vo-quote" aria-live="polite">
          <span className="sr-only">{v.quote}</span>
          <span aria-hidden="true">
            “{txt}
            <i className="caret" />
          </span>
        </blockquote>
        <figcaption className="vo-who">
          <span>{v.name}</span>
          <span className="dim">{v.role}</span>
        </figcaption>
      </figure>
      <ul className="vo-list" aria-label="Clients">
        {voices.map((x, k) => (
          <li key={x.name}>
            <button className={k === i ? "is-on" : ""} onClick={() => setI(k)} aria-pressed={k === i}>
              {x.role.split(", ").slice(1).join(", ")}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
