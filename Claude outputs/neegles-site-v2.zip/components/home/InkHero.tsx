"use client";

import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const VERT = `attribute vec2 p; varying vec2 v; void main(){ v = p*0.5+0.5; gl_Position = vec4(p,0.,1.); }`;
// Two pre-drawn plates (paper/ink and ink/paper). The split line chooses between them; the pointer trail
// pushes rings of ink through the type.
const FRAG = `precision highp float;
varying vec2 v;
uniform sampler2D A; uniform sampler2D B;
uniform vec2 res; uniform float split; uniform float time; uniform float wob;
uniform vec4 pts[20];
float hash(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5); }
void main(){
  vec2 uv = v;
  vec2 asp = vec2(res.x/res.y, 1.0);
  float ink = 0.0;
  vec2 off = vec2(0.0);
  for (int i = 0; i < 20; i++) {
    vec4 q = pts[i];
    if (q.w <= 0.0) continue;
    vec2 d = (uv - q.xy) * asp;
    float r = length(d);
    float age = q.z;
    float ring = sin(r * 70.0 - age * 9.0) * exp(-r * 9.0) * exp(-age * 1.4) * q.w;
    off += normalize(d + 1e-5) * ring * 0.010;
    ink += exp(-r * 26.0) * exp(-age * 2.2) * q.w;
  }
  // idle breathing so the hero is alive before you touch it
  off += vec2(sin(uv.y * 14.0 + time * 0.9), cos(uv.x * 11.0 + time * 0.7)) * 0.0016 * wob;
  vec2 st = uv + off;
  float edge = split + sin(uv.y * 9.0 + time * 0.8) * 0.004;
  vec4 a = texture2D(A, st);
  vec4 b = texture2D(B, st);
  vec4 c = st.x < edge ? a : b;
  // ink bleeds: darken on paper, lift on ink
  float onPaper = st.x < edge ? 1.0 : 0.0;
  c.rgb = mix(c.rgb, onPaper > 0.5 ? c.rgb * (1.0 - ink * 0.55) : c.rgb + ink * 0.18, clamp(ink, 0.0, 1.0));
  // paper grain
  float g = hash(floor(uv * res / 1.5) + floor(time * 12.0)) - 0.5;
  c.rgb += g * 0.035;
  gl_FragColor = vec4(c.rgb, 1.0);
}`;

type Lines = { left: string[]; right: string[] };

/** Draw the hero type into a canvas: one colourway per plate, same layout on both. */
function plate(w: number, h: number, dpr: number, lines: Lines, bg: string, fg: string) {
  const c = document.createElement("canvas");
  c.width = Math.round(w * dpr);
  c.height = Math.round(h * dpr);
  const x = c.getContext("2d")!;
  x.scale(dpr, dpr);
  x.fillStyle = bg;
  x.fillRect(0, 0, w, h);
  x.fillStyle = fg;
  const narrow = w < 760;
  const size = narrow ? Math.min(w * 0.115, 60) : Math.min(w * 0.058, 118);
  x.font = `400 ${size}px ${getComputedStyle(document.documentElement).getPropertyValue("--font-type") || "Courier Prime"}, "Courier New", monospace`;
  x.textBaseline = "alphabetic";
  const lh = size * 1.02;
  if (narrow) {
    const all = [...lines.left, ...lines.right];
    const y0 = h * 0.42 - ((all.length - 1) * lh) / 2;
    all.forEach((t, i) => x.fillText(t, w * 0.07, y0 + i * lh + (i >= lines.left.length ? lh * 0.35 : 0)));
  } else {
    const y0 = h * 0.5 - lh * 0.35;
    lines.left.forEach((t, i) => {
      const tw = x.measureText(t).width;
      x.fillText(t, w * 0.5 - tw - w * 0.02, y0 + i * lh);
    });
    lines.right.forEach((t, i) => x.fillText(t, w * 0.52, y0 + i * lh));
  }
  return c;
}

export default function InkHero() {
  const root = useRef<HTMLElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const sec = root.current!;
    const canvas = cv.current!;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const gl = canvas.getContext("webgl", { antialias: false, premultipliedAlpha: false });
    if (!gl || reduce) {
      sec.classList.add("is-static");
      return;
    }
    const sh = (t: number, s: string) => {
      const o = gl.createShader(t)!;
      gl.shaderSource(o, s);
      gl.compileShader(o);
      return o;
    };
    const prog = gl.createProgram()!;
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      sec.classList.add("is-static");
      return;
    }
    gl.useProgram(prog);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, "p");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const U = (n: string) => gl.getUniformLocation(prog, n);
    const tex = [gl.createTexture()!, gl.createTexture()!];
    tex.forEach((t, i) => {
      gl.activeTexture(gl.TEXTURE0 + i);
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    });
    gl.uniform1i(U("A"), 0);
    gl.uniform1i(U("B"), 1);

    const lines: Lines = { left: ["You run the", "business,"], right: ["we build the", "software."] };
    const css = getComputedStyle(document.documentElement);
    const paper = css.getPropertyValue("--paper").trim() || "#f2ece4";
    const ink = css.getPropertyValue("--ink").trim() || "#0b0b0b";
    let W = 0;
    let H = 0;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
      W = sec.clientWidth;
      H = sec.clientHeight;
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      gl.viewport(0, 0, canvas.width, canvas.height);
      const a = plate(W, H, dpr, lines, paper, ink);
      const b = plate(W, H, dpr, lines, ink, paper);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      [a, b].forEach((c, i) => {
        gl.activeTexture(gl.TEXTURE0 + i);
        gl.bindTexture(gl.TEXTURE_2D, tex[i]);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
      });
      gl.uniform2f(U("res"), canvas.width, canvas.height);
    };

    // pointer trail
    const trail: { x: number; y: number; t: number; s: number }[] = [];
    let lx = 0;
    let ly = 0;
    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width;
      const y = 1 - (e.clientY - r.top) / r.height;
      const sp = Math.hypot(x - lx, y - ly);
      lx = x;
      ly = y;
      if (sp < 0.006) return;
      trail.unshift({ x, y, t: 0, s: Math.min(1, sp * 18) });
      if (trail.length > 20) trail.pop();
    };
    sec.addEventListener("pointermove", onMove);

    const state = { split: window.innerWidth < 760 ? 1 : 0.5, wob: 1 };
    // intro: the halves wipe in after the loader
    const intro = () => gsap.fromTo(state, { split: 1.02 }, { split: window.innerWidth < 760 ? 1 : 0.5, duration: 1.6, ease: "expo.inOut" });
    if (document.documentElement.classList.contains("is-loaded")) intro();
    else window.addEventListener("neegles:loaded", intro, { once: true });
    // scroll: ink floods the page into the dark section below
    const st = ScrollTrigger.create({
      trigger: sec,
      start: "top top",
      end: "bottom top",
      scrub: true,
      onUpdate: (s) => {
        const base = window.innerWidth < 760 ? 1 : 0.5;
        state.split = base * (1 - s.progress);
      },
    });

    const arr = new Float32Array(20 * 4);
    let raf = 0;
    let visible = true;
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting));
    io.observe(sec);
    let last = performance.now();
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (!visible) return;
      arr.fill(0);
      for (let i = trail.length - 1; i >= 0; i--) {
        trail[i].t += dt;
        if (trail[i].t > 3) trail.splice(i, 1);
      }
      trail.forEach((p, i) => arr.set([p.x, p.y, p.t, p.s], i * 4));
      gl.uniform4fv(U("pts[0]"), arr);
      gl.uniform1f(U("split"), state.split);
      gl.uniform1f(U("time"), now / 1000);
      gl.uniform1f(U("wob"), state.wob);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    const start = () => {
      resize();
      raf = requestAnimationFrame(frame);
      sec.classList.add("is-gl");
    };
    (document.fonts?.ready ?? Promise.resolve()).then(start);
    const ro = new ResizeObserver(() => resize());
    ro.observe(sec);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      st.kill();
      sec.removeEventListener("pointermove", onMove);
    };
  }, []);

  return (
    <section ref={root} className="ihero" aria-labelledby="hero-title" data-thread="0.62">
      <canvas ref={cv} className="ihero-gl" aria-hidden="true" />
      {/* real text: visible without WebGL, read by screen readers always */}
      <h1 id="hero-title" className="ihero-text">
        <span className="ihero-l">
          You run the
          <br />
          business,
        </span>
        <span className="ihero-r">
          we build the
          <br />
          software.
        </span>
      </h1>
      <p className="ihero-note ihero-note-l">Neegles — web, mobile and enterprise software for businesses that need technology to do real work.</p>
      <p className="ihero-note ihero-note-r">Built for Africa — made for anywhere</p>
      <a href="#studio" className="ihero-cue" data-magnetic>
        Scroll for the work <span aria-hidden="true">↓</span>
      </a>
    </section>
  );
}
