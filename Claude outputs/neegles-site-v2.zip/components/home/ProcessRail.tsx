"use client";

import { useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import { approach } from "@/lib/content";

gsap.registerPlugin(ScrollTrigger, useGSAP);

/** "Start to finish." A pinned horizontal rail; the line fills as each stage passes the needle. */
export default function ProcessRail() {
  const root = useRef<HTMLElement>(null);
  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add("(min-width: 900px) and (prefers-reduced-motion: no-preference)", () => {
        const track = root.current!.querySelector<HTMLElement>(".rail-track")!;
        const dist = () => track.scrollWidth - window.innerWidth + 80;
        const tl = gsap.timeline({
          scrollTrigger: { trigger: root.current, start: "top top", end: () => `+=${dist()}`, pin: true, scrub: 0.8, invalidateOnRefresh: true },
        });
        tl.to(track, { x: () => -dist(), ease: "none" }, 0);
        tl.fromTo(".rail-fill", { scaleX: 0 }, { scaleX: 1, ease: "none" }, 0);
        gsap.utils.toArray<HTMLElement>(".rail-step").forEach((s) => {
          gsap.fromTo(
            s,
            { opacity: 0.25, y: 40 },
            {
              opacity: 1,
              y: 0,
              ease: "power2.out",
              scrollTrigger: { trigger: s, containerAnimation: tl, start: "left 85%", end: "left 55%", scrub: true },
            },
          );
        });
      });
    },
    { scope: root },
  );
  return (
    <section ref={root} className="rail" id="process" aria-labelledby="rail-title" data-thread="0.1">
      <div className="rail-head">
        <p className="kicker">Process</p>
        <h2 id="rail-title" className="t-xl" data-type>
          Start to <span className="dim">finish.</span>
        </h2>
        <p className="sec-side" data-fade>
          {approach.statement}
        </p>
      </div>
      <div className="rail-track">
        <div className="rail-line" aria-hidden="true">
          <span className="rail-fill" />
        </div>
        <ol className="rail-steps">
          {approach.steps.map((s, i) => (
            <li key={s.title} className="rail-step">
              <span className="rail-n">Stage 0{i + 1}</span>
              <h3>{s.title}</h3>
              <p>{s.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
