import TLink from "@/components/site/TLink";
import { industries } from "@/lib/content";

/** "Pick your industry." Each industry is a printed receipt of the modules we build for it. */
export default function Tickets() {
  return (
    <section className="tickets" id="industries" aria-labelledby="tk-title" data-thread="0.9">
      <div className="sec-head sec-head-dark">
        <p className="kicker">Industries</p>
        <h2 id="tk-title" className="t-xl" data-type>
          Pick your <span className="dim">industry.</span>
        </h2>
        <p className="sec-side" data-fade>
          No two businesses run the same way. These are the systems we build most often, itemised. Pick the one closest to yours
          and we&apos;ll scope the rest with you.
        </p>
      </div>
      <ul className="tk-row" data-stagger>
        {industries.map((ind, i) => (
          <li key={ind.id} className="tk" style={{ ["--tilt" as string]: `${[-2.5, 1.8, -1.2, 2.4][i % 4]}deg` }}>
            <div className="tk-paper">
              <p className="tk-brand">NEEGLES®</p>
              <p className="tk-name">{ind.name}</p>
              <p className="tk-line">{ind.headline}</p>
              <div className="tk-meta">
                <span>No. 00{i + 1}</span>
                <span>Ready to scope</span>
              </div>
              <ul className="tk-items">
                {ind.modules.map((m) => (
                  <li key={m}>
                    <span>{m}</span>
                    <span>INCL.</span>
                  </li>
                ))}
              </ul>
              <div className="tk-total">
                <span>Total</span>
                <span>Built to fit</span>
              </div>
              <TLink href={`/industries/${ind.id}`} className="tk-btn" data-magnetic>
                Explore {ind.name.toLowerCase()} →
              </TLink>
              <div className="tk-bar" aria-hidden="true" />
              <p className="tk-thanks">Thank you. See you at launch.</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
