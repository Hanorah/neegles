"use client";

import Image from "next/image";
import { useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import TLink from "@/components/site/TLink";
import { workItems } from "@/lib/content";

gsap.registerPlugin(ScrollTrigger, useGSAP);

/**
 * "Work that ships." A pinned deck: cards slide in from the right, the current one sits centre stage
 * and the ones you've seen stack up behind it, smaller and dimmer.
 */
export default function WorkDeck() {
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        const cards = gsap.utils.toArray<HTMLElement>(".deck-card");
        const n = cards.length;
        const st = { p: 0 };
        const layout = () => {
          const w = window.innerWidth;
          cards.forEach((c, i) => {
            const d = i - st.p; // <0 seen, 0 current, >0 upcoming
            const seen = Math.min(0, d);
            const ahead = Math.max(0, d);
            gsap.set(c, {
              xPercent: -50 + ahead * 112 + seen * 4,
              x: ahead > 0 ? Math.min(ahead, 1) * w * 0.05 : 0,
              yPercent: -50 + seen * 7,
              scale: 1 + seen * 0.08,
              rotateY: ahead > 0 ? -Math.min(ahead, 1) * 18 : 0,
              opacity: d < -3.5 ? 0 : 1,
              zIndex: 100 + Math.round(-Math.abs(d) * 10 + (d <= 0 ? 50 : 0)),
              filter: `brightness(${1 + Math.max(-0.6, seen * 0.22)})`,
            });
            // only the card in front speaks
            const talk = 1 - Math.min(1, Math.abs(d) * 1.6);
            c.style.setProperty("--talk", talk.toFixed(3));
          });
          const idx = Math.min(n - 1, Math.max(0, Math.round(st.p)));
          root.current?.style.setProperty("--deck-i", String(idx));
          const num = root.current?.querySelector(".deck-count b");
          if (num) num.textContent = String(idx + 1).padStart(2, "0");
        };
        layout();
        gsap.to(st, {
          p: n - 1,
          ease: "none",
          onUpdate: layout,
          scrollTrigger: {
            trigger: root.current,
            start: "top top",
            end: () => `+=${window.innerHeight * (n - 0.3) * 0.9}`,
            pin: ".deck-stage",
            scrub: 0.8,
            invalidateOnRefresh: true,
          },
        });
        // the giant title parts to make room for the deck
        gsap.fromTo(".deck-giant-l", { xPercent: 0 }, { xPercent: -18, ease: "none", scrollTrigger: { trigger: root.current, start: "top top", end: "bottom bottom", scrub: true } });
        gsap.fromTo(".deck-giant-r", { xPercent: 0 }, { xPercent: 18, ease: "none", scrollTrigger: { trigger: root.current, start: "top top", end: "bottom bottom", scrub: true } });
        window.addEventListener("resize", layout);
        return () => window.removeEventListener("resize", layout);
      });
    },
    { scope: root },
  );

  return (
    <section ref={root} className="deck" id="work" aria-labelledby="deck-title" data-thread="0.9">
      <div className="deck-stage">
        <h2 id="deck-title" className="deck-giant" aria-label="Work that ships.">
          <span className="deck-giant-l">Work that</span>
          <span className="deck-giant-r">ships.</span>
        </h2>
        <div className="deck-cards">
          {workItems.map((w, i) => (
            <TLink key={w.slug} href={w.href} className="deck-card" data-cursor="View" aria-label={`${w.name}: ${w.summary}`}>
              <div className="deck-shot">
                <Image src={w.image} alt="" fill sizes="(max-width: 760px) 90vw, 60vw" style={{ objectFit: "cover", objectPosition: "50% 0%" }} priority={i < 2} />
              </div>
              <div className="deck-meta">
                <span className="deck-kind">
                  {String(i + 1).padStart(2, "0")} · {w.kind}
                </span>
                <span className="deck-tags">{w.tags.join(" · ")}</span>
              </div>
              <div className="deck-foot">
                <span className="deck-name">{w.name}</span>
                <span className="deck-arrow" aria-hidden="true">
                  ↗
                </span>
              </div>
            </TLink>
          ))}
        </div>
        <p className="deck-count" aria-hidden="true">
          <b>01</b> / {String(workItems.length).padStart(2, "0")}
        </p>
        <TLink href="/work" className="deck-all pill pill-paper" data-magnetic>
          All work <span aria-hidden="true">→</span>
        </TLink>
      </div>
    </section>
  );
}
