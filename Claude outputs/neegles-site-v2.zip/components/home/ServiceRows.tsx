"use client";

import { useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import TLink from "@/components/site/TLink";
import { capabilities } from "@/lib/content";

gsap.registerPlugin(ScrollTrigger, useGSAP);

/** "What we build." The row nearest the middle of the screen inks in; the rest wait in grey. */
export default function ServiceRows({ title = true }: { title?: boolean }) {
  const root = useRef<HTMLElement>(null);
  useGSAP(
    () => {
      const rows = gsap.utils.toArray<HTMLElement>(".srow");
      rows.forEach((r) =>
        ScrollTrigger.create({
          trigger: r,
          start: "top 58%",
          end: "bottom 42%",
          onToggle: (s) => r.classList.toggle("is-on", s.isActive),
        }),
      );
    },
    { scope: root },
  );
  return (
    <section ref={root} className="services" id="services" aria-labelledby={title ? "svc-title" : undefined} data-thread="0.07">
      {title && (
        <div className="sec-head">
          <p className="kicker">Services</p>
          <h2 id="svc-title" className="t-xl" data-type>
            What we <span className="dim">build.</span>
          </h2>
          <p className="sec-side" data-fade>
            One team for the whole product: the people who design how it looks and works are the people who engineer how it runs.
          </p>
        </div>
      )}
      <ol className="srows">
        {capabilities.map((c, i) => (
          <li key={c.id} className="srow">
            <TLink href={`/services#${c.id}`} className="srow-in" data-cursor="Open">
              <span className="srow-n">0{i + 1}</span>
              <span className="srow-title">{c.title}</span>
              <span className="srow-body">{c.body}</span>
              <span className="srow-arrow" aria-hidden="true">
                →
              </span>
            </TLink>
          </li>
        ))}
      </ol>
    </section>
  );
}
