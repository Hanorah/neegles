import { company } from "@/lib/content";

/** "The studio": one long sentence that types itself, the way you'd explain it across a table. */
export default function Studio() {
  return (
    <section className="studio" id="studio" aria-labelledby="studio-k" data-thread="0.86" data-thread-loop>
      <p id="studio-k" className="kicker">
        The studio
      </p>
      <p className="studio-big" data-type data-type-max="3.4">
        You bring the business. You get software that <span className="dim">does real work</span>: websites, mobile apps and
        enterprise systems, built problem-first and looked after long after launch.
      </p>
      <ul className="studio-tags" data-stagger>
        <li>Web</li>
        <li>Mobile</li>
        <li>Enterprise</li>
        <li>Cloud</li>
        <li>AI</li>
        <li>Automation</li>
      </ul>
      <p className="studio-mission" data-fade>
        {company.mission}
      </p>
    </section>
  );
}
