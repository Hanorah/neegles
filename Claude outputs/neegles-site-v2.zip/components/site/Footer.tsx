import TLink from "./TLink";
import { company, pages, startProjectHref } from "@/lib/content";

/** Closing ask + footer with the giant typewriter wordmark. Shared by every page. */
export default function Footer() {
  return (
    <footer className="site-foot" data-thread="0.15">
      <div className="ask">
        <p className="kicker">Start a project</p>
        <h2 className="ask-title" data-type data-type-keep>
          Let&apos;s build <span className="dim">yours.</span>
        </h2>
        <div className="ask-row">
          <p className="ask-copy" data-fade>
            You run it in the real world. Tell us about the business and what it needs, and we&apos;ll come back with ideas and a
            clear next step.
          </p>
          <a className="pill pill-ink" href={startProjectHref} data-magnetic data-cursor="Email">
            {company.email} <span aria-hidden="true">→</span>
          </a>
        </div>
      </div>

      <div className="foot">
        <div className="foot-grid">
          <p className="foot-line">You run the business. We build the software. Web, mobile and enterprise software from Neegles.</p>
          <nav aria-label="Footer">
            <p className="foot-h">Explore</p>
            {pages.slice(0, 4).map((p) => (
              <TLink key={p.href} href={p.href}>
                {p.label}
              </TLink>
            ))}
          </nav>
          <nav aria-label="Company">
            <p className="foot-h">Company</p>
            {pages.slice(4).map((p) => (
              <TLink key={p.href} href={p.href}>
                {p.label}
              </TLink>
            ))}
          </nav>
          <div>
            <p className="foot-h">Social</p>
            {company.socials.map((s) => (
              <a key={s.label} href={s.href} target="_blank" rel="noreferrer">
                {s.label}
              </a>
            ))}
          </div>
        </div>
        <p className="foot-mark" aria-hidden="true">
          Neegles<sup>®</sup>
        </p>
        <div className="foot-base">
          <span>© {new Date().getFullYear()} {company.legalName}</span>
          <span>Built for Africa, made for anywhere.</span>
        </div>
      </div>
    </footer>
  );
}
