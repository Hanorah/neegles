"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { gsap } from "gsap";
import TLink from "./TLink";
import { company, pages } from "@/lib/content";

const main = pages.filter((p) => ["/work", "/services", "/industries", "/labs", "/about"].includes(p.href));

/** Blend-mode header (reads on light and dark), full-screen typed menu. */
export default function Header() {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(false);
  const menu = useRef<HTMLDivElement>(null);

  useEffect(() => setOpen(false), [path]);

  useEffect(() => {
    let last = window.scrollY;
    const on = () => {
      const y = window.scrollY;
      setHidden(y > 200 && y > last + 2);
      if (y < last - 2) setHidden(false);
      last = y;
    };
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    const el = menu.current;
    if (!el) return;
    document.documentElement.classList.toggle("menu-open", open);
    if (open) {
      window.__lenis?.stop();
      gsap.fromTo(el, { clipPath: "circle(0% at calc(100% - 48px) 36px)" }, { clipPath: "circle(150% at calc(100% - 48px) 36px)", duration: 0.9, ease: "expo.inOut" });
      gsap.fromTo(el.querySelectorAll(".menu-link"), { yPercent: 110 }, { yPercent: 0, duration: 1, ease: "expo.out", stagger: 0.05, delay: 0.25 });
    } else {
      window.__lenis?.start();
    }
  }, [open]);

  const isOn = (href: string) => path === href || path.startsWith(href + "/");

  return (
    <>
      <header className={`hd ${hidden && !open ? "is-hidden" : ""}`}>
        <TLink href="/" className="hd-logo" aria-label="Neegles home" data-magnetic>
          Neegles<sup>®</sup>
        </TLink>
        <nav className="hd-nav" aria-label="Primary">
          {main.map((p) => (
            <TLink key={p.href} href={p.href} className={isOn(p.href) ? "is-on" : ""}>
              <span data-text={p.label}>{p.label}</span>
            </TLink>
          ))}
        </nav>
        <TLink href="/contact" className="hd-cta" data-magnetic>
          Start a project <span aria-hidden="true">↗</span>
        </TLink>
        <button className="hd-burger" aria-expanded={open} aria-controls="menu" onClick={() => setOpen((o) => !o)}>
          <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
          <i />
          <i />
        </button>
      </header>

      <div id="menu" ref={menu} className="menu" hidden={!open} role="dialog" aria-modal="true" aria-label="Menu">
        <ol className="menu-list">
          {[{ label: "Home", href: "/" }, ...pages].map((p, i) => (
            <li key={p.href}>
              <TLink href={p.href} className="menu-link" onClick={() => setOpen(false)}>
                <span className="menu-n">0{i + 1}</span>
                {p.label}
              </TLink>
            </li>
          ))}
        </ol>
        <div className="menu-foot">
          <a href={`mailto:${company.email}`}>{company.email}</a>
          <a href={company.whatsapp} target="_blank" rel="noreferrer">
            WhatsApp ↗
          </a>
        </div>
      </div>
    </>
  );
}
