/**
 * The Neegles wordmark, recoloured with CSS: the official logo file is used as a mask,
 * so it can take `currentColor` on any background.
 */
export default function Wordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`wordmark ${className}`} role="img" aria-label="Neegles">
      <span className="wordmark-fill" aria-hidden="true" />
    </span>
  );
}
