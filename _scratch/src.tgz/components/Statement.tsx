"use client";

import { useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";

gsap.registerPlugin(ScrollTrigger, useGSAP);

const LEAD = "We are a technology company building web, mobile and enterprise software people actually";
const ACCENT = "use,";
const REST =
  "through design, engineering and product thinking. We turn complicated workflows into simple products that scale as your business grows.";

/** Luma statement + Luxfolio scroll highlight: words go from grey to ink as you read. */
export default function Statement() {
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const words = root.current?.querySelectorAll(".w");
      if (!words) return;
      const mm = gsap.matchMedia();
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        gsap.fromTo(
          words,
          { opacity: 0.18 },
          {
            opacity: 1,
            stagger: 0.05,
            ease: "none",
            scrollTrigger: { trigger: ".statement-text", start: "top 80%", end: "bottom 45%", scrub: true },
          },
        );
      });
    },
    { scope: root },
  );

  const split = (s: string, cls = "") =>
    s.split(" ").map((w, i) => (
      <span key={`${cls}${i}`} className={`w ${cls}`}>
        {w}{" "}
      </span>
    ));

  return (
    <section className="statement" id="about" aria-labelledby="about-title">
      <h2 id="about-title" className="caps statement-kicker" data-fade>
        Products without engineering are just promises. We build them properly.
      </h2>
      <p className="statement-text">
        {split(LEAD)}
        {split(ACCENT, "accent")}
        {split(REST, "rest")}
      </p>
    </section>
  );
}
