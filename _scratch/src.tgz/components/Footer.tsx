import { capabilities, company, projects, startProjectHref } from "@/lib/content";
import Marquee from "./Marquee";
import FitText from "./FitText";

/** Common-style CTA, Rekolet giant marquee, Luma dark footer with outlined wordmark. */
export default function Footer() {
  return (
    <>
      <section className="cta" id="contact" aria-labelledby="cta-title">
        <p className="caps cta-kicker" data-fade>
          [ Have something in mind? ]
        </p>
        <h2 id="cta-title" className="cta-title" data-split>
          Let&apos;s build it
          <br />
          <span className="dim">properly.</span>
        </h2>
        <div className="cta-actions" data-fade>
          <a className="btn btn-blue" href={startProjectHref}>
            Start a conversation <span aria-hidden="true">↗</span>
          </a>
          <a className="btn btn-ghost-light" href={company.whatsapp} target="_blank" rel="noreferrer">
            Talk on WhatsApp <span aria-hidden="true">↗</span>
          </a>
        </div>
        <Marquee className="giant" items={["Work with Neegles"]} sep="✳" repeat={3} speed={90} />
      </section>

      <footer className="foot">
        <div className="foot-top">
          <ul className="foot-social caps">
            {company.socials.map((s) => (
              <li key={s.label}>
                <a href={s.href} target="_blank" rel="noreferrer">
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
          <nav className="foot-cols" aria-label="Footer">
            <div>
              <h3 className="caps dim">Company</h3>
              <ul>
                <li><a href="#about">About</a></li>
                <li><a href="#process">Our process</a></li>
                <li><a href="https://neegles.com/careers">Careers</a></li>
                <li><a href="#contact">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="caps dim">Services</h3>
              <ul>
                {capabilities.map((c) => (
                  <li key={c.id}><a href="#services">{c.title}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="caps dim">Work</h3>
              <ul>
                {projects.map((p) => (
                  <li key={p.id}><a href="#work">{p.name}</a></li>
                ))}
                <li><a href="#labs">Labs</a></li>
              </ul>
            </div>
          </nav>
        </div>

        <div className="foot-mid">
          <p className="caps">
            Designed with intent
            <br />
            Built to last
          </p>
          <a className="btn btn-blue btn-sm" href={startProjectHref}>
            Start a project <span aria-hidden="true">→</span>
          </a>
        </div>

        <div className="foot-row caps">
          <a href={`mailto:${company.email}`}>{company.email}</a>
          <a href={company.whatsapp} target="_blank" rel="noreferrer">WhatsApp</a>
          <a href="https://www.linkedin.com/company/neegles/" target="_blank" rel="noreferrer">LinkedIn</a>
        </div>

        <FitText text="NEEGLES" className="foot-mark" />

        <div className="foot-legal caps">
          <span>© {new Date().getFullYear()} {company.legalName}. All rights reserved.</span>
          <a href="https://neegles.com/privacy-policy">Privacy policy</a>
          <a href="https://neegles.com/terms-of-service">Terms of service</a>
        </div>
      </footer>
    </>
  );
}
