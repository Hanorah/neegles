import Image from "next/image";
import { company } from "@/lib/content";

/** Luma "Why choose": asymmetric grid of image, white, blue and dark cards. */
export default function Why() {
  return (
    <section className="why" aria-labelledby="why-title">
      <div className="why-head">
        <h2 id="why-title" className="why-title" data-split>
          Why choose
          <br />
          Neegles
        </h2>
        <p className="caps why-side" data-fade>
          We combine product thinking, engineering and long-term support, so the software we deliver doesn&apos;t just launch.
          It lasts.
        </p>
      </div>

      <div className="why-grid">
        <figure className="wcard wcard-img wcard-tall" data-fade>
          <Image src="/industries/professional-services.webp" alt="A team reviewing dashboards together" fill sizes="(max-width: 820px) 100vw, 33vw" style={{ objectFit: "cover" }} />
          <span className="chip caps">Our approach</span>
          <figcaption>
            Ideas without engineering are just slides. We build with <span className="blue">intent</span>.
          </figcaption>
        </figure>

        <article className="wcard wcard-white" data-fade>
          <div className="wcard-top caps">
            <span className="blue">(01)</span>
            <span aria-hidden="true">↗</span>
          </div>
          <div>
            <h3>Problem-first thinking</h3>
            <p className="caps">{company.mission}</p>
          </div>
        </article>

        <figure className="wcard wcard-img" data-fade>
          <Image src="/labs/prism.webp" alt="Prism, an AI image editing surface from Neegles Labs" fill sizes="(max-width: 820px) 100vw, 33vw" style={{ objectFit: "cover", objectPosition: "50% 30%" }} />
          <span className="chip caps chip-corner">Neegles Labs</span>
        </figure>

        <article className="wcard wcard-blue" data-fade>
          <div className="wcard-top caps">
            <span>(02)</span>
            <span aria-hidden="true">↗</span>
          </div>
          <div>
            <h3>Built for Africa, made for anywhere</h3>
            <p className="caps">{company.vision}</p>
          </div>
        </article>

        <article className="wcard wcard-dark" data-fade>
          <div className="wcard-top caps">
            <span className="blue-l">(03)</span>
            <span aria-hidden="true">↗</span>
          </div>
          <p className="wcard-big">24/7</p>
          <div>
            <h3>Support that stays</h3>
            <p className="caps">Technical support and continuous improvement to keep your product running at its best.</p>
          </div>
        </article>
      </div>
    </section>
  );
}
