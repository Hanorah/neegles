"use client";

import Image from "next/image";
import { useState } from "react";
import { industries, startProjectHref } from "@/lib/content";

const VERBS = ["Track.", "Sell.", "Run.", "Build."];

/** Luma's dark band: monochrome image, headline, and four columns with big accent words. */
export default function Industries() {
  const [active, setActive] = useState(0);

  return (
    <section className="ind" id="industries" aria-labelledby="ind-title">
      <div className="ind-bg" aria-hidden="true">
        {industries.map((ind, i) => (
          <Image
            key={ind.id}
            src={ind.image}
            alt=""
            fill
            sizes="100vw"
            className={active === i ? "on" : ""}
            style={{ objectFit: "cover" }}
          />
        ))}
      </div>
      <div className="ind-top">
        <h2 id="ind-title" className="caps ind-title" data-fade>
          Every system we build is shaped around the industry it runs in.
        </h2>
        <div className="ind-side" data-fade>
          <p className="caps">We partner with operators who have outgrown spreadsheets and off-the-shelf tools.</p>
          <a href={startProjectHref} className="btn btn-ghost-light btn-sm">
            Talk to Neegles <span aria-hidden="true">→</span>
          </a>
        </div>
      </div>

      <ol className="ind-cols">
        {industries.map((ind, i) => (
          <li
            key={ind.id}
            className={`ind-col ${active === i ? "ind-on" : ""}`}
            onMouseEnter={() => setActive(i)}
            onFocus={() => setActive(i)}
            tabIndex={0}
            aria-label={`${ind.name}: ${ind.headline}`}
          >
            <div className="ind-col-head caps">
              <h3>{ind.name}</h3>
              <span>(0{i + 1})</span>
            </div>
            <p className="ind-verb" aria-hidden="true">
              {VERBS[i]}
            </p>
            <div className="ind-more">
              <div className="ind-more-in">
                <p className="ind-headline">{ind.headline}</p>
                <ul>
                  {ind.modules.map((m) => (
                    <li key={m}>{m}</li>
                  ))}
                </ul>
              </div>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
