"use client";

import { useState } from "react";
import { capabilities, startProjectHref } from "@/lib/content";

/** Luxfolio "What we do": condensed caps rows that open into detail. */
export default function Services() {
  const [open, setOpen] = useState(0);

  return (
    <section className="services" id="services" aria-labelledby="services-title">
      <div className="services-head">
        <p className="cond services-kicker" data-fade>
          Services
        </p>
        <h2 id="services-title" className="cond services-title" data-split>
          What we do
        </h2>
        <p className="services-note" data-fade>
          — software built around how your business actually works, not the other way round.
        </p>
      </div>

      <ol className="svc-list">
        {capabilities.map((c, i) => {
          const isOpen = open === i;
          return (
            <li key={c.id} className={`svc ${isOpen ? "svc-open" : ""}`} data-fade onMouseEnter={() => setOpen(i)}>
              <h3>
                <button
                  className="svc-btn"
                  aria-expanded={isOpen}
                  aria-controls={`svc-${c.id}`}
                  onClick={() => setOpen(isOpen ? -1 : i)}
                >
                  <span className="svc-num">(0{i + 1})</span>
                  <span className="cond svc-name">{c.title}</span>
                  <span className="svc-plus" aria-hidden="true" />
                </button>
              </h3>
              <div id={`svc-${c.id}`} className="svc-body" role="region" aria-label={c.title}>
                <div className="svc-inner">
                  <p className="svc-desc">{c.body}</p>
                  <ul className="svc-tags">
                    {c.includes.map((t) => (
                      <li key={t} className="tag">
                        {t}
                      </li>
                    ))}
                  </ul>
                  <a className="cond svc-link" href={startProjectHref}>
                    Start a project →
                  </a>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
