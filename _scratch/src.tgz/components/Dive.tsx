"use client";

import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import { capabilities } from "@/lib/content";
import manifest from "@/lib/dive-manifest.json";

gsap.registerPlugin(ScrollTrigger, useGSAP);

type Manifest = { frames: number; cut: number; width: number; height: number; tiers: Record<string, string> };
const M = manifest as Manifest;

const pad = (n: number) => String(n).padStart(4, "0");

/** Pick the lightest frame set that still looks sharp on this screen. */
function pickTier() {
  const w = Math.min(window.innerWidth, 2560) * Math.min(window.devicePixelRatio || 1, 2);
  const conn = (navigator as Navigator & { connection?: { saveData?: boolean; effectiveType?: string } }).connection;
  if (conn?.saveData || /2g/.test(conn?.effectiveType || "")) return "sm";
  if (w <= 900) return "sm";
  if (w <= 1700) return "md";
  return "lg";
}

/**
 * The opening: a pre-rendered (Blender / Mantaflow / Cycles) laptop-into-water sequence,
 * scrubbed by scroll on a canvas. Frames are painted, not seeked, so scrubbing is exact
 * in both directions on every browser.
 */
export default function Dive() {
  const root = useRef<HTMLElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const frames = useRef<(HTMLImageElement | null)[]>([]);
  const current = useRef(0);
  const [ready, setReady] = useState(false);
  const [loaded, setLoaded] = useState(0);

  // Load frames: first frame immediately, then the rest in scrub order with limited concurrency.
  useEffect(() => {
    const tier = pickTier();
    const base = M.tiers[tier];
    const list: (HTMLImageElement | null)[] = new Array(M.frames).fill(null);
    frames.current = list;
    let alive = true;
    let count = 0;

    const load = (i: number) =>
      new Promise<void>((res) => {
        const img = new Image();
        img.decoding = "async";
        img.src = `${base}/${pad(i + 1)}.webp`;
        const done = () => {
          if (!alive) return res();
          list[i] = img;
          count++;
          setLoaded(count);
          if (i === current.current || i === 0) draw(current.current);
          res();
        };
        img.onload = () => (img.decode ? img.decode().then(done, done) : done());
        img.onerror = () => res();
      });

    (async () => {
      await load(0);
      if (!alive) return;
      setReady(true);
      // coarse pass first (every 4th frame) so a fast scroller always sees motion, then fill in
      const order: number[] = [];
      for (let s of [8, 4, 2, 1]) for (let i = 0; i < M.frames; i += s) if (!order.includes(i)) order.push(i);
      let k = 0;
      const worker = async () => {
        while (alive && k < order.length) {
          const i = order[k++];
          if (!list[i]) await load(i);
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Nearest loaded frame to i (so scrubbing never shows a blank while loading).
  function nearest(i: number) {
    const f = frames.current;
    if (f[i]) return f[i];
    for (let d = 1; d < M.frames; d++) {
      if (f[i - d]) return f[i - d];
      if (f[i + d]) return f[i + d];
    }
    return null;
  }

  function draw(i: number) {
    const c = canvas.current;
    if (!c) return;
    const img = nearest(i);
    if (!img) return;
    const ctx = c.getContext("2d", { alpha: false });
    if (!ctx) return;
    const cw = c.width;
    const ch = c.height;
    // cover, but never crop the laptop out on tall screens: cap the zoom
    const s = Math.max(cw / img.naturalWidth, Math.min(ch / img.naturalHeight, (cw / img.naturalWidth) * 1.9));
    const w = img.naturalWidth * s;
    const h = img.naturalHeight * s;
    ctx.fillStyle = "#010406";
    ctx.fillRect(0, 0, cw, ch);
    ctx.drawImage(img, (cw - w) / 2, (ch - h) / 2, w, h);
  }

  // Size the canvas to the screen.
  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const fit = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      c.width = Math.round(c.clientWidth * dpr);
      c.height = Math.round(c.clientHeight * dpr);
      draw(current.current);
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(c);
    return () => ro.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();

      mm.add("(prefers-reduced-motion: no-preference)", () => {
        const state = { f: 0 };
        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: {
            trigger: root.current,
            start: "top top",
            end: "bottom bottom",
            scrub: 0.6,
          },
        });

        // the film runs across the first ~88% of the section
        tl.to(state, {
          f: M.frames - 1,
          duration: 88,
          onUpdate: () => {
            const i = Math.round(state.f);
            if (i !== current.current) {
              current.current = i;
              draw(i);
            }
          },
        }, 0);

        // opening title leaves as the laptop drops
        tl.to(".dive-open", { opacity: 0, y: -60, duration: 10, ease: "power2.in" }, 4);
        tl.to(".dive-cue", { opacity: 0, duration: 4 }, 0);

        // impact line
        tl.fromTo(".dive-beat-1", { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 6, ease: "power2.out" }, 20);
        tl.to(".dive-beat-1", { opacity: 0, y: -40, duration: 6, ease: "power2.in" }, 34);

        // underwater: what we build
        tl.fromTo(".dive-beat-2", { opacity: 0, y: 50 }, { opacity: 1, y: 0, duration: 8, ease: "power2.out" }, 48);
        tl.fromTo(".dive-caps li", { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 5, stagger: 1.6, ease: "power2.out" }, 56);
        tl.to(".dive-beat-2", { opacity: 0, y: -50, duration: 7, ease: "power2.in" }, 80);

        // depth gauge
        tl.fromTo(".dive-depth-fill", { scaleY: 0 }, { scaleY: 1, duration: 88 }, 0);

        // surface into the paper site
        tl.fromTo(".dive-veil", { opacity: 0 }, { opacity: 1, duration: 12, ease: "power1.in" }, 88);
      });

      mm.add("(prefers-reduced-motion: reduce)", () => {
        // a single still that tells the story; all copy visible
        current.current = Math.round(M.cut + (M.frames - M.cut) * 0.35);
        draw(current.current);
      });
    },
    { scope: root },
  );

  const pct = Math.round((loaded / M.frames) * 100);

  return (
    <section ref={root} className="dive" id="top" aria-labelledby="dive-title">
      <div className="dive-stage">
        {/* the first frame doubles as the poster (and the LCP image) */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img className="dive-poster" src={`${M.tiers.md}/0001.webp`} alt="" aria-hidden="true" fetchPriority="high" style={{ opacity: ready ? 0 : 1 }} />
        <canvas ref={canvas} className="dive-canvas" aria-hidden="true" />
        <div className="dive-grain" aria-hidden="true" />

        <div className="dive-open">
          <p className="caps dive-kicker">Web · Mobile · Enterprise software</p>
          <h1 id="dive-title" className="dive-title">
            Software,
            <br />
            built to ship.
          </h1>
        </div>

        <p className="dive-beat dive-beat-1" aria-hidden="true">
          Products without engineering
          <br />
          are just <em>promises.</em>
        </p>

        <div className="dive-beat dive-beat-2">
          <h2 className="dive-h2">
            We build what&apos;s
            <br />
            beneath the surface.
          </h2>
          <ul className="dive-caps caps">
            {capabilities.map((c, i) => (
              <li key={c.id}>
                <span>0{i + 1}</span>
                {c.title}
              </li>
            ))}
          </ul>
        </div>

        <div className="dive-cue caps" aria-hidden="true">
          <span>Scroll to dive</span>
          <span className="dive-cue-line" />
        </div>

        <div className="dive-depth caps" aria-hidden="true">
          <span>0 m</span>
          <span className="dive-depth-track">
            <span className="dive-depth-fill" />
          </span>
          <span>{pct < 100 ? `${pct}%` : "deep"}</span>
        </div>

        <div className="dive-veil" aria-hidden="true" />
      </div>
    </section>
  );
}
