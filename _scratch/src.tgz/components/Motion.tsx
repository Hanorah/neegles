"use client";

import { useGSAP } from "@gsap/react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";

gsap.registerPlugin(ScrollTrigger, SplitText, useGSAP);

/**
 * Global scroll choreography driven by data attributes:
 *  [data-split]    headings rise in line by line
 *  [data-fade]     elements fade up on enter
 *  [data-clip]     images unmask upward
 *  [data-parallax] elements drift horizontally (value = % range)
 */
export default function Motion() {
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add("(prefers-reduced-motion: no-preference)", () => {
      document.documentElement.classList.add("motion");

      gsap.utils.toArray<HTMLElement>("[data-split]").forEach((el) => {
        SplitText.create(el, {
          type: "lines",
          mask: "lines",
          autoSplit: true,
          onSplit: (self) =>
            gsap.from(self.lines, {
              yPercent: 105,
              duration: 1.2,
              ease: "expo.out",
              stagger: 0.08,
              scrollTrigger: { trigger: el, start: "top 88%" },
            }),
        });
      });

      gsap.utils.toArray<HTMLElement>("[data-fade]").forEach((el) => {
        gsap.from(el, {
          y: 36,
          opacity: 0,
          duration: 1.1,
          ease: "expo.out",
          scrollTrigger: { trigger: el, start: "top 92%" },
        });
      });

      gsap.utils.toArray<HTMLElement>("[data-clip]").forEach((el, i) => {
        gsap.fromTo(
          el,
          { clipPath: "inset(100% 0% 0% 0% round 18px)" },
          { clipPath: "inset(0% 0% 0% 0% round 18px)", duration: 1.5, ease: "expo.inOut", delay: 0.35 + i * 0.12 },
        );
        const img = el.querySelector("img");
        if (img)
          gsap.fromTo(img, { scale: 1.25 }, { scale: 1, duration: 2, ease: "expo.out", delay: 0.35 + i * 0.12 });
      });

      gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((el) => {
        const amt = parseFloat(el.dataset.parallax || "10");
        gsap.fromTo(
          el,
          { xPercent: -amt / 2 },
          { xPercent: amt / 2, ease: "none", scrollTrigger: { trigger: el, start: "top bottom", end: "bottom top", scrub: true } },
        );
      });

      return () => document.documentElement.classList.remove("motion");
    });
  });

  return null;
}
