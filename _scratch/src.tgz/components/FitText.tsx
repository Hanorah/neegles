"use client";

import { useLayoutEffect, useRef } from "react";

/** A single line of display type scaled to exactly fill its container's width. Letters rise in on load. */
export default function FitText({ text, className = "", as: Tag = "p" }: { text: string; className?: string; as?: "p" | "h2" | "span" }) {
  const box = useRef<HTMLDivElement>(null);
  const line = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const b = box.current;
    const l = line.current;
    if (!b || !l) return;
    const fit = () => {
      l.style.fontSize = "100px";
      const w = l.scrollWidth;
      const cs = getComputedStyle(b);
      const avail = b.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      if (w) l.style.fontSize = `${(100 * avail) / w}px`;
    };
    fit();
    document.fonts?.ready.then(fit);
    const ro = new ResizeObserver(fit);
    ro.observe(b);
    return () => ro.disconnect();
  }, [text]);

  return (
    <div ref={box} className={`fit ${className}`} aria-hidden="true">
      <Tag ref={line as never} className="fit-line">
        {text.split("").map((c, i) => (
          <span key={i} className="fit-char" style={{ animationDelay: `${0.08 + i * 0.05}s` }}>
            {c}
          </span>
        ))}
      </Tag>
    </div>
  );
}
