"use client";

import { useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import { approach } from "@/lib/content";

gsap.registerPlugin(ScrollTrigger, useGSAP);

const ROT = [-4, 3, -2, 4, -3, 2];

/** Creagen notebook: hand-circled headline, taped note cards joined by dashed lines. */
export default function Process() {
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        const path = root.current?.querySelector<SVGPathElement>(".scribble path");
        if (path) {
          const len = path.getTotalLength();
          gsap.fromTo(
            path,
            { strokeDasharray: len, strokeDashoffset: len },
            { strokeDashoffset: 0, duration: 1.4, ease: "power2.inOut", scrollTrigger: { trigger: path, start: "top 80%" } },
          );
        }
        gsap.utils.toArray<HTMLElement>(".note").forEach((n, i) => {
          gsap.from(n, {
            y: 120,
            rotate: ROT[i] * 4,
            opacity: 0,
            duration: 1.1,
            ease: "expo.out",
            scrollTrigger: { trigger: n, start: "top 92%" },
          });
        });
      });
    },
    { scope: root },
  );

  return (
    <section className="process" id="process" aria-labelledby="process-title">
      <div className="process-head">
        <h2 id="process-title" className="process-title">
          Messy problems.
          <br />
          <span className="circled">
            Clean software.
            <svg className="scribble" viewBox="0 0 400 110" preserveAspectRatio="none" aria-hidden="true">
              <path d="M18 64 C 30 18, 210 6, 352 22 C 402 30, 396 84, 300 96 C 190 108, 40 104, 14 74 C 2 58, 30 40, 70 34" />
            </svg>
          </span>
        </h2>
        <p className="process-note">
          Every project moves through the same six stages. What changes is how long each one takes, and that depends on how much
          there is to untangle.
        </p>
      </div>

      <ol className="notes">
        {approach.steps.map((s, i) => (
          <li key={s.title} className={`note ${i % 2 === 0 ? "note-blue" : "note-paper"}`} style={{ ["--r" as string]: `${ROT[i]}deg` }}>
            <span className="tape" aria-hidden="true" />
            <div className="note-top">
              <span>0{i + 1}</span>
              <span>Stage</span>
            </div>
            <h3>{s.title}</h3>
            <p>{s.body}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
