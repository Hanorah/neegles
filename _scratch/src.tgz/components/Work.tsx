"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { labs, projects, type Project } from "@/lib/content";

type Filter = "all" | "client" | "labs";

/** Selected work: Luxfolio's giant WORK type, Inex project rows, Luma numbered cards. */
export default function Work() {
  const [filter, setFilter] = useState<Filter>("all");
  const [active, setActive] = useState<Project | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const d = dialog.current;
    if (!d) return;
    if (active) {
      d.showModal();
      window.__lenis?.stop();
    } else if (d.open) d.close();
  }, [active]);

  const showClient = filter !== "labs";
  const showLabs = filter !== "client";

  return (
    <section className="work" id="work" aria-labelledby="work-title">
      <div className="work-head">
        <p className="cond work-kicker" data-fade>
          Our work
        </p>
        <h2 id="work-title" className="cond work-title" data-split>
          Our signature
        </h2>
        <div className="work-giant" aria-hidden="true" data-parallax="-12">
          <span className="cond">WO</span>
          <span className="work-giant-img">
            <Image src="/work/kike-home.webp" alt="" fill sizes="30vw" style={{ objectFit: "cover", objectPosition: "50% 8%" }} />
          </span>
          <span className="cond">RK</span>
        </div>
      </div>

      <div className="work-bar">
        <p className="work-count">
          Selected work <span className="caps">(02 products · 04 labs)</span>
        </p>
        <div className="filters" role="group" aria-label="Filter work">
          {(
            [
              ["all", "All"],
              ["client", "Client work"],
              ["labs", "Labs"],
            ] as [Filter, string][]
          ).map(([k, l]) => (
            <button key={k} className={`pill ${filter === k ? "pill-on" : ""}`} aria-pressed={filter === k} onClick={() => setFilter(k)}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {showClient && (
        <ol className="projects">
          {projects.map((p, i) => (
            <li key={p.id} className="project" data-fade>
              <div className="project-info">
                <p className="caps project-num">0{i + 1}.</p>
                <h3 className="project-name">{p.name}</h3>
                <p className="project-sum">{p.summary}</p>
                <ul className="project-tags">
                  <li className="tag">{p.industry}</li>
                  {p.built.slice(0, 2).map((b) => (
                    <li key={b} className="tag">
                      {b}
                    </li>
                  ))}
                </ul>
                <button className="link-arrow" onClick={() => setActive(p)}>
                  <span aria-hidden="true">↳</span> View project<span className="sr-only">: {p.name}</span>
                </button>
              </div>
              <button className="project-shots" onClick={() => setActive(p)} aria-label={`Open ${p.name} project details`}>
                {p.gallery.slice(0, 3).map((g, k) => (
                  <span key={g.src} className={`shot shot-${k}`}>
                    <Image src={g.src} alt="" fill sizes="(max-width: 820px) 33vw, 16vw" style={{ objectFit: "cover", objectPosition: "50% 0%" }} />
                  </span>
                ))}
              </button>
              <p className="caps project-year">Live product</p>
            </li>
          ))}
        </ol>
      )}

      {showLabs && (
        <div className="labs" id="labs">
          <div className="labs-head">
            <h3 className="labs-title">
              Labs <span className="caps">— {labs.headline}</span>
            </h3>
            <p className="caps labs-sub">{labs.sub}</p>
          </div>
          <ol className="cards">
            {labs.items.map((l, i) => (
              <li key={l.id} className="card" data-fade>
                <div className="card-img">
                  <span className="badge">0{i + 1}</span>
                  <Image src={l.image} alt={`${l.name}: ${l.body}`} fill sizes="(max-width: 820px) 50vw, 24vw" style={{ objectFit: "cover", objectPosition: "0% 0%" }} />
                </div>
                <div className="card-cap caps">
                  <span>
                    {l.name} · {l.tag}
                  </span>
                </div>
                <p className="card-body">{l.body}</p>
              </li>
            ))}
          </ol>
        </div>
      )}

      <dialog
        ref={dialog}
        className="sheet"
        aria-labelledby="sheet-title"
        onClose={() => {
          setActive(null);
          window.__lenis?.start();
        }}
        onClick={(e) => {
          if (e.target === dialog.current) setActive(null);
        }}
      >
        {active && (
          <div className="sheet-inner">
            <div className="sheet-head">
              <p className="caps">Project file · {active.industry}</p>
              <button className="caps sheet-close" onClick={() => setActive(null)} autoFocus>
                Close ✕
              </button>
            </div>
            <h2 id="sheet-title" className="cond sheet-title">
              {active.name}
            </h2>
            <div className="sheet-grid">
              <div>
                <h3 className="caps sheet-label">The problem</h3>
                <p>{active.challenge}</p>
              </div>
              <div>
                <h3 className="caps sheet-label">What we built</h3>
                <p>{active.summary}</p>
              </div>
              <div>
                <h3 className="caps sheet-label">Inside</h3>
                <ul className="sheet-list">
                  {active.built.map((b) => (
                    <li key={b}>{b}</li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="sheet-gallery">
              {active.gallery.map((g) => (
                <Image key={g.src} src={g.src} alt={g.alt} width={g.w} height={g.h} sizes="(max-width: 820px) 92vw, 60vw" />
              ))}
            </div>
          </div>
        )}
      </dialog>
    </section>
  );
}
