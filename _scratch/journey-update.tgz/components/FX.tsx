"use client";

import { useEffect } from "react";
import { useGSAP } from "@gsap/react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger, useGSAP);

/**
 * Site-wide motion layer on top of <Motion/>:
 * progress bar, custom cursor, magnetic buttons, 3D card tilt, image parallax,
 * section reveals, velocity skew on big type, hero wordmark exit.
 */
export default function FX() {
  // cursor + magnetic + tilt (pointer devices only)
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
    const root = document.documentElement;
    root.classList.add("fx-cursor");

    const dot = document.createElement("div");
    dot.className = "cursor-dot";
    const ring = document.createElement("div");
    ring.className = "cursor-ring";
    document.body.append(dot, ring);
    const dx = gsap.quickTo(dot, "x", { duration: 0.08, ease: "power3" });
    const dy = gsap.quickTo(dot, "y", { duration: 0.08, ease: "power3" });
    const rx = gsap.quickTo(ring, "x", { duration: 0.45, ease: "power3" });
    const ry = gsap.quickTo(ring, "y", { duration: 0.45, ease: "power3" });
    const move = (e: PointerEvent) => {
      dx(e.clientX);
      dy(e.clientY);
      rx(e.clientX);
      ry(e.clientY);
      const t = e.target as HTMLElement | null;
      const hot = !!t?.closest("a, button, [role=button], .wcard, .project, figure");
      ring.classList.toggle("is-hot", hot);
    };
    const down = () => ring.classList.add("is-down");
    const up = () => ring.classList.remove("is-down");
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);

    // magnetic buttons
    const mags = Array.from(document.querySelectorAll<HTMLElement>(".btn, .round-btn, .arrow, .menu-btn, .pill-nav a, .svc-btn, .link-arrow"));
    const magOff: (() => void)[] = [];
    mags.forEach((el) => {
      const mx = gsap.quickTo(el, "x", { duration: 0.5, ease: "elastic.out(1, 0.4)" });
      const my = gsap.quickTo(el, "y", { duration: 0.5, ease: "elastic.out(1, 0.4)" });
      const onMove = (e: PointerEvent) => {
        const r = el.getBoundingClientRect();
        mx((e.clientX - (r.left + r.width / 2)) * 0.3);
        my((e.clientY - (r.top + r.height / 2)) * 0.4);
      };
      const onLeave = () => {
        mx(0);
        my(0);
      };
      el.addEventListener("pointermove", onMove);
      el.addEventListener("pointerleave", onLeave);
      magOff.push(() => {
        el.removeEventListener("pointermove", onMove);
        el.removeEventListener("pointerleave", onLeave);
      });
    });

    // 3D tilt on cards
    const tilts = Array.from(document.querySelectorAll<HTMLElement>(".wcard, .project-shots > *, .sheet-gallery > *, .notes > *, .voice-card"));
    const tiltOff: (() => void)[] = [];
    tilts.forEach((el) => {
      el.style.transformStyle = "preserve-3d";
      const onMove = (e: PointerEvent) => {
        const r = el.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        gsap.to(el, { rotateY: px * 9, rotateX: -py * 9, transformPerspective: 900, duration: 0.6, ease: "power3.out" });
        el.style.setProperty("--gx", `${(px + 0.5) * 100}%`);
        el.style.setProperty("--gy", `${(py + 0.5) * 100}%`);
      };
      const onLeave = () => gsap.to(el, { rotateY: 0, rotateX: 0, duration: 0.9, ease: "elastic.out(1, 0.5)" });
      el.classList.add("fx-tilt");
      el.addEventListener("pointermove", onMove);
      el.addEventListener("pointerleave", onLeave);
      tiltOff.push(() => {
        el.removeEventListener("pointermove", onMove);
        el.removeEventListener("pointerleave", onLeave);
      });
    });

    return () => {
      root.classList.remove("fx-cursor");
      dot.remove();
      ring.remove();
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      magOff.forEach((f) => f());
      tiltOff.forEach((f) => f());
    };
  }, []);

  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add("(prefers-reduced-motion: no-preference)", () => {
      // reading progress
      gsap.to(".fx-progress span", {
        scaleX: 1,
        ease: "none",
        scrollTrigger: { start: 0, end: "max", scrub: 0.3 },
      });

      // hero wordmark leaves with weight: rises, stretches, blurs
      const mark = document.querySelector(".hero-mark");
      if (mark)
        gsap.to(mark, {
          yPercent: -35,
          scaleY: 1.25,
          filter: "blur(6px)",
          opacity: 0.25,
          transformOrigin: "50% 100%",
          ease: "none",
          scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true },
        });

      // sections rise in from a rounded, inset window
      gsap.utils.toArray<HTMLElement>("main > section").forEach((sec) => {
        if (sec.matches(".hero, .dive, .process, .cta")) return;
        gsap.fromTo(
          sec,
          { clipPath: "inset(7% 3% 0% 3% round 40px)", y: 80 },
          {
            clipPath: "inset(0% 0% 0% 0% round 0px)",
            y: 0,
            ease: "none",
            scrollTrigger: { trigger: sec, start: "top bottom", end: "top 35%", scrub: 0.8 },
          },
        );
      });

      // image parallax inside every section (skips the hero frames, which unmask on load)
      gsap.utils.toArray<HTMLImageElement>("main section img").forEach((img) => {
        if (img.closest("[data-clip], .dive, .hero")) return;
        const box = img.parentElement;
        if (!box) return;
        gsap.fromTo(
          img,
          { yPercent: -7, scale: 1.16 },
          { yPercent: 7, scale: 1.16, ease: "none", scrollTrigger: { trigger: box, start: "top bottom", end: "bottom top", scrub: true } },
        );
      });

      // big type leans into the scroll
      const skewers = gsap.utils.toArray<HTMLElement>(".marquee, .work-giant, .cta-title, .labs-title, .why-title, .voices-title");
      const setters = skewers.map((el) => gsap.quickTo(el, "skewY", { duration: 0.5, ease: "power3" }));
      let skew = 0;
      ScrollTrigger.create({
        onUpdate: (self) => {
          skew = gsap.utils.clamp(-6, 6, self.getVelocity() / -350);
        },
      });
      const decay = () => {
        skew *= 0.88;
        if (Math.abs(skew) < 0.01) skew = 0;
        setters.forEach((s) => s(skew));
      };
      gsap.ticker.add(decay);

      // staggered children for every list/grid that isn't already animated
      gsap.utils.toArray<HTMLElement>(".svc-list, .why-grid, .project-shots, .sheet-list, .notes, .voice-tabs, .foot-cols, .project-tags, .svc-tags").forEach((list) => {
        const kids = Array.from(list.children).filter((k) => !(k as HTMLElement).hasAttribute("data-fade"));
        if (!kids.length) return;
        gsap.from(kids, {
          y: 60,
          rotateX: -25,
          opacity: 0,
          transformPerspective: 800,
          transformOrigin: "50% 0%",
          duration: 1.1,
          ease: "expo.out",
          stagger: 0.07,
          scrollTrigger: { trigger: list, start: "top 85%" },
        });
      });

      // CTA: the ask scales up out of the dark
      gsap.from(".cta-title", {
        scale: 0.82,
        opacity: 0,
        filter: "blur(10px)",
        duration: 1.4,
        ease: "expo.out",
        scrollTrigger: { trigger: ".cta", start: "top 70%" },
      });

      // header pill drops away on the way down, returns on the way up
      const bar = document.querySelector<HTMLElement>(".bar");
      if (bar)
        ScrollTrigger.create({
          start: 400,
          end: "max",
          onUpdate: (self) => gsap.to(bar, { yPercent: self.direction === 1 ? -160 : 0, duration: 0.45, ease: "power3.out", overwrite: "auto" }),
        });
      return () => gsap.ticker.remove(decay);
    });
  });

  return (
    <div className="fx-progress" aria-hidden="true">
      <span />
    </div>
  );
}
