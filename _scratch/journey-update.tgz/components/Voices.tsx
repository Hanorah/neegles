"use client";

import { useEffect, useState } from "react";
import { voices } from "@/lib/content";

/** Luma "Client voices": one large quote at a time, with company tabs. */
export default function Voices() {
  const [i, setI] = useState(0);
  const v = voices[i];
  // the floating MacBook mirrors the current testimonial on its screen
  useEffect(() => {
    window.dispatchEvent(new CustomEvent("neegles:voice", { detail: i }));
  }, [i]);
  const n = voices.length;
  const company = v.role.split(", ").slice(1).join(", ");
  const words = v.quote.split(" ");
  const hi = Math.max(0, words.findIndex((w) => /Neegles/.test(w)));

  return (
    <section className="voices" aria-labelledby="voices-title">
      <div className="voices-head">
        <h2 id="voices-title" className="voices-title" data-split>
          Client voices
        </h2>
        <p className="caps blue" aria-live="polite">
          ({String(i + 1).padStart(2, "0")} / {String(n).padStart(2, "0")})
        </p>
      </div>

      <div className="voices-body">
        <div className="voice-card" aria-hidden="true">
          <div className="laptop-slot voices-slot" data-laptop-slot="voices" />
          <span className="voice-mono">{company.split(" ").map((w) => w[0]).join("").slice(0, 3)}</span>
          <span className="chip caps">
            <span className="dot" /> {company}
          </span>
        </div>
        <figure className="voice" key={i}>
          <span className="voice-mark" aria-hidden="true">
            “
          </span>
          <blockquote>
            {words.map((w, k) => (
              <span key={k} className={k === hi ? "blue" : undefined}>
                {w}{" "}
              </span>
            ))}
          </blockquote>
          <figcaption className="caps">
            <span className="rule" aria-hidden="true" />
            {v.name} <span className="dim">{v.role}</span>
          </figcaption>
          <div className="voice-nav">
            <button className="arrow" onClick={() => setI((i - 1 + n) % n)} aria-label="Previous testimonial">
              ←
            </button>
            <button className="arrow arrow-on" onClick={() => setI((i + 1) % n)} aria-label="Next testimonial">
              →
            </button>
            <span className="voice-progress" aria-hidden="true">
              <span style={{ width: `${((i + 1) / n) * 100}%` }} />
            </span>
          </div>
        </figure>
      </div>

      <ul className="voice-tabs caps" aria-label="Clients">
        {voices.map((x, k) => (
          <li key={x.name}>
            <button className={k === i ? "on" : ""} aria-pressed={k === i} onClick={() => setI(k)}>
              {x.role.split(", ").slice(1).join(", ")}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
