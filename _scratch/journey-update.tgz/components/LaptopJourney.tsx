"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import rig from "@/lib/dive-rig.json";
import { filmRect, journey } from "@/lib/journey";
import { voices, capabilities } from "@/lib/content";

type V3 = [number, number, number];
type RigFrame = { rig: { p: V3; q: [number, number, number, number]; s: number }; cam: { p: V3; fw: V3; up: V3 } };
const R = rig as unknown as { vfov: number; frames: Record<string, RigFrame> };
const F1 = R.frames["1"];

const LID_OPEN = 1.1868; // matches the rendered film
const LID_SHUT = Math.PI - 0.035;
const LAPTOP_W = 0.312 * F1.rig.s;

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const smooth = (t: number) => t * t * (3 - 2 * t);

/* ---------------- screen content ---------------- */
type Screen =
  | { kind: "why" }
  | { kind: "voice"; i: number }
  | { kind: "word"; i: number }
  | { kind: "final" };

const WORDS = ["Web apps.", "Mobile apps.", "Enterprise systems.", "Cloud.", "AI.", "Automation."];

function paintScreen(ctx: CanvasRenderingContext2D, s: Screen, finalImg: HTMLImageElement | null) {
  const W = ctx.canvas.width;
  const H = ctx.canvas.height;
  if (s.kind === "final" && finalImg?.complete) {
    ctx.drawImage(finalImg, 0, 0, W, H);
    return;
  }
  const g = ctx.createRadialGradient(W * 0.5, H * 0.45, 0, W * 0.5, H * 0.45, W * 0.75);
  g.addColorStop(0, "#0c2248");
  g.addColorStop(1, "#030a16");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  // menu bar
  ctx.fillStyle = "#0a1222";
  ctx.fillRect(0, 0, W, 38);
  ctx.font = "500 22px Inter, Arial, sans-serif";
  ctx.fillStyle = "#e1e8f5";
  ctx.textBaseline = "top";
  ctx.fillText("Neegles", 70, 8);
  ctx.fillText("neegles.com", W - 230, 8);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  if (s.kind === "why") {
    ctx.fillStyle = "#7f9be0";
    ctx.font = "500 30px 'JetBrains Mono', monospace";
    ctx.fillText("(WHY NEEGLES)", W / 2, H * 0.3);
    ctx.fillStyle = "#fff";
    ctx.font = "700 120px Inter, Arial, sans-serif";
    ctx.fillText("We build", W / 2, H * 0.47);
    ctx.fillText("with intent.", W / 2, H * 0.6);
  } else if (s.kind === "voice") {
    const v = voices[s.i % voices.length];
    const company = v.role.split(", ").slice(1).join(", ");
    ctx.fillStyle = "#7f9be0";
    ctx.font = "500 30px 'JetBrains Mono', monospace";
    ctx.fillText(`CLIENT  ·  ${company.toUpperCase()}`, W / 2, H * 0.24);
    ctx.fillStyle = "#fff";
    ctx.font = "600 64px Inter, Arial, sans-serif";
    // wrap the quote
    const words = `“${v.quote}”`.split(" ");
    const lines: string[] = [];
    let line = "";
    for (const w of words) {
      const t = line ? `${line} ${w}` : w;
      if (ctx.measureText(t).width > W * 0.78) {
        lines.push(line);
        line = w;
      } else line = t;
    }
    lines.push(line);
    const y0 = H * 0.5 - ((lines.length - 1) * 78) / 2;
    lines.forEach((l, k) => ctx.fillText(l, W / 2, y0 + k * 78));
    ctx.fillStyle = "#aac3ff";
    ctx.font = "500 32px Inter, Arial, sans-serif";
    ctx.fillText(`${v.name}  —  ${v.role}`, W / 2, y0 + lines.length * 78 + 40);
  } else if (s.kind === "word") {
    ctx.fillStyle = "#7f9be0";
    ctx.font = "500 30px 'JetBrains Mono', monospace";
    ctx.fillText(`WE BUILD  0${(s.i % WORDS.length) + 1}`, W / 2, H * 0.32);
    ctx.fillStyle = "#fff";
    ctx.font = "700 150px Inter, Arial, sans-serif";
    ctx.fillText(WORDS[s.i % WORDS.length], W / 2, H * 0.52);
    ctx.fillStyle = "#4a7dff";
    ctx.fillRect(W / 2 - 60, H * 0.64, 120, 6);
    ctx.fillStyle = "#aac3ff";
    ctx.font = "500 34px Inter, Arial, sans-serif";
    const cap = capabilities[s.i % capabilities.length];
    ctx.fillText(cap.kicker, W / 2, H * 0.72);
  }
  ctx.textAlign = "start";
}

/**
 * The real-time MacBook that travels from "Why choose Neegles" into the client section, then free-falls
 * (screen cycling through what we build) and hands over, pose-for-pose, to the pre-rendered water film.
 */
export default function LaptopJourney() {
  const holder = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const el = holder.current;
    if (!el) return;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.AgXToneMapping;
    renderer.toneMappingExposure = 1.15;
    el.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environmentIntensity = 0.9;
    const key = new THREE.DirectionalLight(0xffffff, 2.2);
    key.position.set(-0.8, 1.6, 1.2);
    const rim = new THREE.DirectionalLight(0xbfd2ff, 2.4);
    rim.position.set(0.4, 0.8, -1.6);
    scene.add(key, rim, new THREE.AmbientLight(0x8fa8ff, 0.35));

    const cam = new THREE.PerspectiveCamera(R.vfov, 16 / 9, 0.01, 50);
    cam.position.set(...F1.cam.p);
    cam.up.set(...F1.cam.up);
    cam.lookAt(new THREE.Vector3(...F1.cam.p).add(new THREE.Vector3(...F1.cam.fw)));
    cam.updateMatrixWorld();
    const camFw = new THREE.Vector3(...F1.cam.fw).normalize();

    // screen texture
    const sc = document.createElement("canvas");
    sc.width = 1600;
    sc.height = 1078;
    const sctx = sc.getContext("2d")!;
    const screenTex = new THREE.CanvasTexture(sc);
    screenTex.flipY = false;
    screenTex.colorSpace = THREE.SRGBColorSpace;
    screenTex.anisotropy = 8;
    const finalImg = new Image();
    finalImg.src = "/three/screen.webp";
    let screenKey = "";
    const setScreen = (s: Screen) => {
      const k = JSON.stringify(s) + (finalImg.complete ? "1" : "0");
      if (k === screenKey) return;
      screenKey = k;
      paintScreen(sctx, s, finalImg);
      screenTex.needsUpdate = true;
    };

    // materials, matched to the Blender look
    const gray = new THREE.MeshPhysicalMaterial({ color: 0x2a2c31, metalness: 1, roughness: 0.34, clearcoat: 0.15, clearcoatRoughness: 0.4 });
    const mats: Record<string, THREE.Material> = {
      Base: gray,
      Lid: gray,
      Keys: new THREE.MeshStandardMaterial({ color: 0x050506, roughness: 0.55, metalness: 0 }),
      Well: new THREE.MeshStandardMaterial({ color: 0x0b0c0e, roughness: 0.5, metalness: 0.5 }),
      Trackpad: new THREE.MeshPhysicalMaterial({ color: 0x2b2d33, metalness: 0.85, roughness: 0.16 }),
      Hinge: new THREE.MeshStandardMaterial({ color: 0x0a0a0b, metalness: 0.5, roughness: 0.45 }),
      Bezel: new THREE.MeshPhysicalMaterial({ color: 0x000000, roughness: 0.04, clearcoat: 1, clearcoatRoughness: 0.03 }),
      Notch: new THREE.MeshBasicMaterial({ color: 0x000000 }),
      Display: new THREE.MeshBasicMaterial({ map: screenTex, toneMapped: false }),
      Grille: new THREE.MeshStandardMaterial({ color: 0x15161a, metalness: 0.8, roughness: 0.5 }),
    };

    let laptop: THREE.Object3D | null = null;
    let lid: THREE.Object3D | null = null;
    new GLTFLoader().load("/three/macbook.glb", (g) => {
      const root = g.scene.getObjectByName("Rig") ?? g.scene;
      root.traverse((o) => {
        const m = o as THREE.Mesh;
        if (!m.isMesh) return;
        const n = m.name.startsWith("Grille") ? "Grille" : (m.name.replace(/[._]\d+$/, "") as string);
        const parentName = m.parent?.name?.startsWith("Grille") ? "Grille" : (m.parent?.name ?? "");
        m.material = mats[n] ?? mats[parentName] ?? gray;
      });
      lid = root.getObjectByName("LidPivot") ?? null;
      root.position.set(0, 0, 0);
      root.quaternion.identity();
      root.scale.setScalar(1);
      laptop = new THREE.Group();
      laptop.add(root);
      laptop.scale.setScalar(F1.rig.s);
      scene.add(laptop);
    });

    const diveQ = new THREE.Quaternion(...F1.rig.q);
    const divePos = new THREE.Vector3(...F1.rig.p);
    const tmpQ = new THREE.Quaternion();
    const tmpE = new THREE.Euler();
    const ray = new THREE.Raycaster();
    const ndc = new THREE.Vector2();

    let cw = 0;
    let ch = 0;
    const resize = () => {
      cw = window.innerWidth;
      ch = window.innerHeight;
      renderer.setSize(cw, ch, false);
      renderer.domElement.style.width = cw + "px";
      renderer.domElement.style.height = ch + "px";
      const fr = filmRect(cw, ch);
      cam.aspect = 16 / 9;
      cam.setViewOffset(fr.w, fr.h, -fr.x, -fr.y, cw, ch);
      cam.updateProjectionMatrix();
    };
    resize();
    window.addEventListener("resize", resize);

    /** world pose that makes the laptop sit over a DOM slot */
    const slotPose = (r: DOMRect, out: THREE.Vector3) => {
      const fr = filmRect(cw, ch);
      const wpx = Math.max(60, r.width * 0.92);
      const D = (LAPTOP_W * fr.h) / (wpx * 2 * Math.tan(THREE.MathUtils.degToRad(R.vfov / 2)));
      ndc.set(((r.left + r.width / 2) / cw) * 2 - 1, -((r.top + r.height * 0.58) / ch) * 2 + 1);
      ray.setFromCamera(ndc, cam);
      const dir = ray.ray.direction;
      out.copy(cam.position).addScaledVector(dir, D / Math.max(0.2, dir.dot(camFw)));
      return out;
    };

    let voiceI = 0;
    const onVoice = (e: Event) => {
      voiceI = (e as CustomEvent<number>).detail ?? 0;
    };
    window.addEventListener("neegles:voice", onVoice);

    const pA = new THREE.Vector3();
    const pB = new THREE.Vector3();
    const qA = new THREE.Quaternion();
    const qB = new THREE.Quaternion();
    let raf = 0;
    let visible = false;

    const slotQ = (yaw: number, out: THREE.Quaternion) => out.setFromEuler(tmpE.set(0.32, yaw, 0.02));

    const tick = (t: number) => {
      raf = requestAnimationFrame(tick);
      if (!laptop) return;
      const why = document.querySelector<HTMLElement>('[data-laptop-slot="why"]');
      const voi = document.querySelector<HTMLElement>('[data-laptop-slot="voices"]');
      const dive = document.querySelector<HTMLElement>(".dive");
      if (!why || !voi || !dive) return;
      const rw = why.getBoundingClientRect();
      const rv = voi.getBoundingClientRect();
      const rd = dive.getBoundingClientRect();
      const cy = ch / 2;
      const yWhy = rw.top + rw.height / 2;
      const yVoi = rv.top + rv.height / 2;

      let show = true;
      let lidA = LID_OPEN;
      let screen: Screen = { kind: "why" };
      const idle = Math.sin(t / 900) * 0.04;

      if (rd.top <= 0 && journey.diveActive) {
        // ---- free fall above the water, hand-off to the film
        const f = journey.fall;
        laptop.position.copy(divePos);
        tmpQ.setFromEuler(tmpE.set(Math.sin(f * 9) * 0.06 * (1 - f), Math.sin(f * 6 + 1) * 0.12 * (1 - f), Math.sin(f * 7) * 0.05 * (1 - f)));
        laptop.quaternion.copy(diveQ).multiply(tmpQ);
        screen = f > 0.82 ? { kind: "final" } : { kind: "word", i: Math.floor(f * 6.99) };
        show = !journey.handoff;
      } else if (yWhy > cy) {
        // ---- appearing in "Why choose Neegles"
        const a = clamp((ch - rw.top) / (ch * 0.75));
        slotPose(rw, laptop.position);
        laptop.position.y += (1 - smooth(a)) * -0.25;
        slotQ(-0.55 + (1 - a) * 2.2 + idle, laptop.quaternion);
        lidA = THREE.MathUtils.lerp(LID_SHUT, LID_OPEN, smooth(clamp((a - 0.35) / 0.65)));
        laptop.scale.setScalar(F1.rig.s * (0.6 + 0.4 * smooth(a)));
        show = a > 0;
      } else if (yVoi > cy) {
        // ---- travelling from Why to the client section, with a full turn on the way
        const b = smooth(clamp((cy - yWhy) / Math.max(1, yVoi - yWhy)));
        slotPose(rw, pA);
        slotPose(rv, pB);
        laptop.position.lerpVectors(pA, pB, b);
        laptop.position.z += Math.sin(b * Math.PI) * 0.35;
        slotQ(-0.55 + b * (Math.PI * 2 + 0.95) + idle, laptop.quaternion);
        laptop.scale.setScalar(F1.rig.s);
        screen = b > 0.5 ? { kind: "voice", i: voiceI } : { kind: "why" };
      } else {
        // ---- from the client section into the dive pose
        const span = Math.max(1, rd.top - 0 + (cy - yVoi));
        const c = smooth(clamp((cy - yVoi) / span));
        slotPose(rv, pA);
        laptop.position.lerpVectors(pA, divePos, c);
        slotQ(0.4 + idle * (1 - c), qA);
        qB.copy(diveQ);
        laptop.quaternion.slerpQuaternions(qA, qB, c);
        laptop.scale.setScalar(F1.rig.s);
        screen = c > 0.6 ? { kind: "word", i: 0 } : { kind: "voice", i: voiceI };
        show = rd.bottom > 0;
      }

      if (lid) lid.rotation.set(lidA, 0, 0);
      if (show !== visible) {
        visible = show;
        el.style.opacity = show ? "1" : "0";
      }
      if (!show) return;
      setScreen(screen);
      renderer.render(scene, cam);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("neegles:voice", onVoice);
      renderer.dispose();
      pmrem.dispose();
      el.innerHTML = "";
    };
  }, []);

  return <div ref={holder} className="laptop-journey" aria-hidden="true" />;
}
