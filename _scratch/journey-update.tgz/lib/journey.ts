/**
 * Shared state between the real-time MacBook (LaptopJourney) and the pre-rendered water film (Dive).
 * Both draw against the same virtual 16:9 "film frame", so the hand-off from 3D to video is pixel-aligned.
 */

export const FILM_ASPECT = 16 / 9;

/** Where the 16:9 film frame sits on a cw×ch screen (CSS px). Dive draws its frames into this rect. */
export function filmRect(cw: number, ch: number) {
  const iw = 1600;
  const ih = 900;
  const s = Math.max(cw / iw, Math.min(ch / ih, (cw / iw) * 2.0));
  const w = iw * s;
  const h = ih * s;
  const x = (cw - w) / 2;
  // wide screens: nudge the film down so the laptop clears the header
  const y = h >= ch ? (ch - h) / 2 + ch * 0.07 : (ch - h) / 2;
  return { x, y, w, h };
}

export const journey = {
  /** 0..1 progress through the free-fall before the water (owned by Dive) */
  fall: 0,
  /** true once the rendered film has taken over the laptop */
  handoff: false,
  /** true while the Dive stage is pinned on screen */
  diveActive: false,
};
